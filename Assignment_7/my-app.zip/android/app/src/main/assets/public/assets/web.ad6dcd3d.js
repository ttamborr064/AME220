import { W as WebPlugin } from "./index.b5facc45.js";
class SplashScreenWeb extends WebPlugin {
  async show(_options) {
    return void 0;
  }
  async hide(_options) {
    return void 0;
  }
}
export { SplashScreenWeb };
